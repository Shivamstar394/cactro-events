import React from 'react';

type VideoDetailsProps = {
  videoId: string;
  title?: string;
  description?: string;
  viewCount?: string;
};

const VideoDetails: React.FC<VideoDetailsProps> = ({
  videoId,
  title,
  description,
  viewCount,
}) => {
  return (
    <div className="video-details" style={{ marginBottom: 20 }}>
      <iframe
        width="100%"
        height="360"
        src={`https://www.youtube.com/embed/${videoId}`}
        title={title || 'YouTube video player'}
        frameBorder="0"
        allowFullScreen
      ></iframe>
      <h2>{title}</h2>
      <p>{description}</p>
      <p>
        <strong>Views:</strong> {viewCount}
      </p>
    </div>
  );
};

export default VideoDetails;
