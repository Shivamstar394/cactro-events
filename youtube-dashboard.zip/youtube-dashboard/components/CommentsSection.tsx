import React, { useEffect, useState } from 'react';

type Comment = {
  id: string;
  author: string;
  text: string;
};

type CommentsSectionProps = {
  videoId: string;
};

const CommentsSection: React.FC<CommentsSectionProps> = ({ videoId }) => {
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');

  // For demo, comments saved in local state (can extend to DB later)
  useEffect(() => {
    const savedComments = localStorage.getItem(`comments-${videoId}`);
    if (savedComments) setComments(JSON.parse(savedComments));
  }, [videoId]);

  const addComment = () => {
    if (!newComment.trim()) return;

    const comment: Comment = {
      id: Date.now().toString(),
      author: 'User',
      text: newComment.trim(),
    };

    const updated = [comment, ...comments];
    setComments(updated);
    setNewComment('');
    localStorage.setItem(`comments-${videoId}`, JSON.stringify(updated));
  };

  return (
    <div className="comments-section" style={{ marginTop: 30 }}>
      <h3>Comments</h3>
      <textarea
        value={newComment}
        onChange={e => setNewComment(e.target.value)}
        placeholder="Add a comment..."
        rows={3}
        style={{ width: '100%', resize: 'none' }}
      />
      <button onClick={addComment} style={{ marginTop: 10 }}>
        Add Comment
      </button>
      <ul style={{ listStyle: 'none', padding: 0, marginTop: 20 }}>
        {comments.map(comment => (
          <li key={comment.id} style={{ marginBottom: 15 }}>
            <strong>{comment.author}</strong>: {comment.text}
          </li>
        ))}
        {comments.length === 0 && <p>No comments yet.</p>}
      </ul>
    </div>
  );
};

export default CommentsSection;
