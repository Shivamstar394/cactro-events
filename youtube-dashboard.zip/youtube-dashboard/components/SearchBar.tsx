import React, { useState } from 'react';

type SearchBarProps = {
  onSearch: (query: string) => void;
};

const SearchBar: React.FC<SearchBarProps> = ({ onSearch }) => {
  const [query, setQuery] = useState('');

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query.trim());
    }
  };

  return (
    <form onSubmit={submitSearch} style={{ marginBottom: 20 }}>
      <input
        type="text"
        value={query}
        onChange={e => setQuery(e.target.value)}
        placeholder="Search YouTube videos..."
        style={{ padding: 8, width: '80%', maxWidth: 400, marginRight: 8 }}
      />
      <button type="submit">Search</button>
    </form>
  );
};

export default SearchBar;
