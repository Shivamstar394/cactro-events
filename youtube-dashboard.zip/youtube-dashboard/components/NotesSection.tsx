import React, { useEffect, useState } from 'react';

type NotesSectionProps = {
  videoId: string;
};

const NotesSection: React.FC<NotesSectionProps> = ({ videoId }) => {
  const [notes, setNotes] = useState('');
  
  useEffect(() => {
    const savedNotes = localStorage.getItem(`notes-${videoId}`);
    if (savedNotes) setNotes(savedNotes);
  }, [videoId]);

  const saveNotes = (value: string) => {
    setNotes(value);
    localStorage.setItem(`notes-${videoId}`, value);
  };

  return (
    <div className="notes-section" style={{ marginTop: 30 }}>
      <h3>Notes</h3>
      <textarea
        value={notes}
        onChange={e => saveNotes(e.target.value)}
        placeholder="Write your notes here..."
        rows={5}
        style={{ width: '100%', resize: 'vertical' }}
      />
    </div>
  );
};

export default NotesSection;
