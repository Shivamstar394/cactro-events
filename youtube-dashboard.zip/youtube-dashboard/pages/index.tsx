import React, { useState, useEffect } from 'react';
import VideoDetails from '../components/videodetails';
import CommentsSection from '../components/CommentsSection';
import NotesSection from '../components/NotesSection';
import SearchBar from '../components/SearchBar';

const DEFAULT_VIDEO_ID = 'dQw4w9WgXcQ'; // Replace with your default video id

const HomePage = () => {
  const [videoId, setVideoId] = useState(DEFAULT_VIDEO_ID);
  const [videoMeta, setVideoMeta] = useState<{ title: string; description: string; viewCount: string }>({
    title: '',
    description: '',
    viewCount: '',
  });

  const fetchVideoDetails = async (id: string) => {
    const apiKey = process.env.NEXT_PUBLIC_YOUTUBE_API_KEY;
    const url = `https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics&id=${id}&key=${apiKey}`;

    const res = await fetch(url);
    const data = await res.json();

    if (data.items && data.items.length > 0) {
      const video = data.items[0];
      setVideoMeta({
        title: video.snippet.title,
        description: video.snippet.description,
        viewCount: video.statistics.viewCount,
      });
    } else {
      setVideoMeta({ title: 'Video not found', description: '', viewCount: '0' });
    }
  };

  useEffect(() => {
    fetchVideoDetails(videoId);
  }, [videoId]);

  const handleSearch = (query: string) => {
    // For demo, just assume query is video id
    // Ideally you do a search API call and get actual video ID(s)
    setVideoId(query);
  };

  return (
    <div>
      <SearchBar onSearch={handleSearch} />
      <VideoDetails
        videoId={videoId}
        title={videoMeta.title}
        description={videoMeta.description}
        viewCount={videoMeta.viewCount}
      />
      <CommentsSection videoId={videoId} />
      {/* <NotesSection videoId={videoId} /> */}
    </div>
  );
};

export default HomePage;
